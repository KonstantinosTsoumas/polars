def main():
    print("Hello from polars-tutorial!")


if __name__ == "__main__":
    main()
